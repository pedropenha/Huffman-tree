#include <stdio.h>
#include <stdlib.h>

struct registro{
    int simbolo;
    char palavra[20];
    int freq;
    char cod_huffman[20];
};

typedef struct registro Registro;

struct lista{
    Registro reg;
    struct lista *prox;
};

typedef struct lista Lista;

struct huffman{
    int freq;
    int simbolo;
    struct huffman *esq, *dir;
};

typedef struct huffman Huffman;

struct fila{
    Huffman *info;
    struct fila *prox;
};

typedef struct fila Fila;


char isEmpty(Fila *F){
    return F == NULL;
}

void criaCaixaHuffman(Huffman **H, int simbolo, int freq){
    (*H)->freq = freq;
    (*H)->simbolo = simbolo;
    (*H)->esq = (*H)->dir = NULL;
}

Fila *criaCaixaFila(Huffman *H){
    Fila *nova;
    nova = (Fila *) malloc (sizeof(Fila));
    nova->info = H;
    nova->prox = NULL;

    return nova;
}

//Funcionando
// void enqueue(Huffman *H, Fila **F){
//     Fila *aux = *F, *nova;
//     if(isEmpty(aux)){
//         *F = criaCaixaFila(H);
//     }else{
//         while(H->freq > aux->info->freq && aux != NULL){
//             aux = aux->prox;
//         }
//         nova = criaCaixaFila(H);
//         nova->prox = aux;
//         *F = nova;;
//     }
// }

void enqueue(Huffman *H, Fila **F){
    Fila *aux = *F;
    Fila *nova = (Fila *) malloc (sizeof(Fila));
    if(isEmpty(aux)){
        aux->info = H;
        aux->prox = NULL;
    }else{
        while(H->freq > aux->info->freq){
            aux = aux->prox;
        }
        nova->info = H;
        nova->prox = aux;
        aux->prox = nova;
    }
}

void exibeFila(Fila *F){
    while(F != NULL){
        printf("%d\n", F->info->freq);
        F = F->prox;
    }
}